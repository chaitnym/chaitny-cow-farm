# Chaitny Cow Farm — Android-friendly starter

## Included in this package
- `index.html`: mobile dashboard prototype with cow registration, AI/treatment records, expenses, charts, checklist and JSON backup.
- `firestore.rules`: starter security rules for future Firebase cloud sync; members can read/create/edit, only the owner UID can permanently delete.

## Current status — important
The included HTML is a working **local browser prototype**. Its records are stored in the browser on the current device. Firebase cloud synchronization, Google sign-in, doctor directory, and family permissions are **not yet wired into this HTML**. The rules file is a starting template, not an automatically active security setting. Do not treat the app as a cloud-backed production app until Firebase is configured and tested.

## Open and use on Android
1. Download and extract `Chaitny_Cow_Farm_Starter.zip`.
2. Open your Replit project in Chrome.
3. Replace the project's `index.html` with the included `index.html` contents.
4. Run the project and test using dummy data first.
5. Use the dashboard's Export Backup option regularly. Browser storage can be lost if site data is cleared.

## Firebase cloud sync setup (free tier may be sufficient for small tests)
1. Go to https://console.firebase.google.com and create a project.
2. Add a Web app and copy its Firebase config.
3. Enable Authentication → Google sign-in and create a Firestore database.
4. The current `index.html` is not connected to Firebase yet. Before adding live family records, Firebase Auth/Firestore code must be integrated and tested.
5. For the security rules, replace `OWNER_UID_PLACEHOLDER` with the owner's Firebase Authentication UID, then publish the rules in Firestore → Rules.
6. Create `farms/chaitny-family/members/{uid}` documents for allowed family accounts with `active: true` and `role: "member"`. The owner UID is configured in the rules. Never allow a member to publish rules or change their role.

## Planned next items to finish
- Firebase Google sign-in and live cross-phone sync.
- Veterinary contact directory (doctor name, phone, qualification, clinic and payment preference).
- Per-visit/per-treatment payment history and pending balance.
- Owner-only deletion enforced by published Firestore rules, audit log, and safer restore flow.
- Installable PWA/offline handling and final phone testing.

## Data safety
- Local records stay on one browser/device; they do not sync to family phones.
- Export backups and store them somewhere safe.
- Firestore rules are not active until you publish them in your Firebase project.
- Test with dummy records before entering real farm or veterinary data.
